package problems;

import adt.bst.BST;
import adt.bt.BTNode;

public class BSTSumLeavesImpl implements BSTSumLeaves{
	
    public int sumLeaves(BST<Integer> bst){
    	int result = 0;
    	if(!bst.isEmpty()) {
    		result = sumTotal(bst.getRoot());
    	}	
    	return result;
    }
    
    public int sumTotal(BTNode<Integer> node){
    	int sum = 0;	
    	if(!node.isEmpty()) {		
    		sum += sumTotal(node.getLeft());
    		if(node.isLeaf()) {
    			sum += node.getData();
    		}
    		sum += sumTotal(node.getRight());	
    	}	
    	return sum;
    }
    
}
